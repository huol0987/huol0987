## [1.1.5](https://github.com/mooyoul/melon-ticket-actions/compare/v1.1.4...v1.1.5) (2022-01-18)


### Bug Fixes

* **deps:** update dependency axios to ^0.25.0 ([71f790e](https://github.com/mooyoul/melon-ticket-actions/commit/71f790e8ed33bde762c7dce57e65060b312ff768))

## [1.1.4](https://github.com/mooyoul/melon-ticket-actions/compare/v1.1.3...v1.1.4) (2021-10-25)


### Bug Fixes

* **deps:** update dependency axios to ^0.24.0 ([71b9fe6](https://github.com/mooyoul/melon-ticket-actions/commit/71b9fe6ece93e9996a99f49d4a2356977167e39b))

## [1.1.3](https://github.com/mooyoul/melon-ticket-actions/compare/v1.1.2...v1.1.3) (2020-10-23)


### Bug Fixes

* **deps:** update dependency axios to ^0.21.0 ([95c7199](https://github.com/mooyoul/melon-ticket-actions/commit/95c7199a8f2528b62c721562a8f1ff3b467c9d22))

## [1.1.2](https://github.com/mooyoul/melon-ticket-actions/compare/v1.1.1...v1.1.2) (2020-10-01)


### Bug Fixes

* **deps:** update dependency @actions/core to v1.2.6 [security] ([b646738](https://github.com/mooyoul/melon-ticket-actions/commit/b646738f74a696ede2941053319b788ba00a055f))

## [1.1.1](https://github.com/mooyoul/melon-ticket-actions/compare/v1.1.0...v1.1.1) (2020-08-21)


### Bug Fixes

* **deps:** update dependency axios to ^0.20.0 ([bb64155](https://github.com/mooyoul/melon-ticket-actions/commit/bb64155bc60e749770e260674614105b7c334e13))

# [1.1.0](https://github.com/mooyoul/melon-ticket-actions/compare/v1.0.1...v1.1.0) (2019-12-16)


### Bug Fixes

* fix missing querystring indicator ([874e35a](https://github.com/mooyoul/melon-ticket-actions/commit/874e35a14292ea6734197f4f41c97c878847c930))


### Features

* support custom message ([e6db3f4](https://github.com/mooyoul/melon-ticket-actions/commit/e6db3f496881ecf2b04e92d1862073620d53ae17))

## [1.0.1](https://github.com/mooyoul/melon-ticket-actions/compare/v1.0.0...v1.0.1) (2019-12-15)


### Bug Fixes

* fix invalid method ([e743bd5](https://github.com/mooyoul/melon-ticket-actions/commit/e743bd57f1ae77855ccd1aff1121efdde4467ad3))
* remove hard-coded product url ([5891c4a](https://github.com/mooyoul/melon-ticket-actions/commit/5891c4aa4a1f270b6ad237672544e8b397d5fb42))

# 1.0.0 (2019-12-15)


### Features

* initial commit ([b0ef7a7](https://github.com/mooyoul/melon-ticket-actions/commit/b0ef7a7b3a1fda287de14d87a0e5c5bd1abeedde))
