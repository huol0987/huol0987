#!/bin/sh -l

set -e

NODE_PATH=/var/task/node_modules node /var/task/index.js
